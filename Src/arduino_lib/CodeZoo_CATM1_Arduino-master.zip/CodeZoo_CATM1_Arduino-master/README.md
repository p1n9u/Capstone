# CodeZoo_CATM1_Arduino
Development resource, Arduino library and example code for LTE-Cat.m1 module produced by CodeZoo

### CodeZoo LTE-Cat.m1
![CATM1_single](https://user-images.githubusercontent.com/22319034/84928458-5eb58d80-b109-11ea-8349-bacfa3e9e747.PNG)

### Arduino NANO-33-IoT and CAT.M1
![NANO_33_IoT_BG96](https://user-images.githubusercontent.com/22319034/90127541-517eed00-dda0-11ea-998e-0135a1846583.png)

### Arduino MEGA2560 and CAT.M1
![MEGA2560_BG96](https://user-images.githubusercontent.com/22319034/85375442-44e4d200-b571-11ea-951c-48bb70986e93.png)

### ESP32 and CAT.M1
![ESP32_BG96](https://user-images.githubusercontent.com/22319034/85370592-e536f880-b569-11ea-99a8-fb443b19cbb8.png)

